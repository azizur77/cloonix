#ifndef SPICE_CHANNEL_ENUMS_H
#define SPICE_CHANNEL_ENUMS_H

#warning "deprecated: please include spice-glib-enums.h"
#include "spice-glib-enums.h"

#endif /* SPICE_CHANNEL_ENUMS_H */
